import MusicPlayerApp from "@/components/music-player-app"

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0a1929] text-white">
      <MusicPlayerApp />
    </div>
  )
}

